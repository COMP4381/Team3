
# DoublePropertyImpl

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bean** | **Object** |  |  [optional]
**name** | **String** |  |  [optional]
**value** | **Double** |  |  [optional]



