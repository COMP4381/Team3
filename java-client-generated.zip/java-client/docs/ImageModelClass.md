
# ImageModelClass

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | 1 | 
**image** | [**Image**](Image.md) | 2 | 
**filteid** | **Integer** | 3 |  [optional]
**place** | **String** | 4 |  [optional]
**url** | **String** | 5 |  [optional]
**googQuality** | **Boolean** | 6 |  [optional]



