
# Throwable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cause** | [**Throwable**](Throwable.md) |  |  [optional]
**localizedMessage** | **String** |  |  [optional]
**message** | **String** |  |  [optional]
**stackTrace** | [**List&lt;StackTraceElement&gt;**](StackTraceElement.md) |  |  [optional]
**suppressed** | [**List&lt;Throwable&gt;**](Throwable.md) |  |  [optional]



