
# StackTraceElement

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**className** | **String** |  |  [optional]
**fileName** | **String** |  |  [optional]
**lineNumber** | **Integer** |  |  [optional]
**methodName** | **String** |  |  [optional]
**nativeMethod** | **Boolean** |  |  [optional]



