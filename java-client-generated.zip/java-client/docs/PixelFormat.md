
# PixelFormat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**premultiplied** | **Boolean** |  |  [optional]
**type** | [**TypeEnum**](#TypeEnum) |  |  [optional]
**writable** | **Boolean** |  |  [optional]


<a name="TypeEnum"></a>
## Enum: TypeEnum
Name | Value
---- | -----
INT_ARGB_PRE | &quot;INT_ARGB_PRE&quot;
INT_ARGB | &quot;INT_ARGB&quot;
BYTE_BGRA_PRE | &quot;BYTE_BGRA_PRE&quot;
BYTE_BGRA | &quot;BYTE_BGRA&quot;
BYTE_RGB | &quot;BYTE_RGB&quot;
BYTE_INDEXED | &quot;BYTE_INDEXED&quot;



