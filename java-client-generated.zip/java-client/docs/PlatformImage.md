
# PlatformImage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pixelScale** | **Float** |  |  [optional]
**platformPixelFormat** | [**PixelFormat**](PixelFormat.md) |  |  [optional]
**writable** | **Boolean** |  |  [optional]



