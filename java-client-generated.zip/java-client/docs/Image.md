
# Image

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**backgroundLoading** | **Boolean** |  |  [optional]
**error** | **Boolean** |  |  [optional]
**exception** | [**Exception**](Exception.md) |  |  [optional]
**height** | **Double** |  |  [optional]
**pixelReader** | [**PixelReader**](PixelReader.md) |  |  [optional]
**platformImage** | [**PlatformImage**](PlatformImage.md) |  |  [optional]
**preserveRatio** | **Boolean** |  |  [optional]
**progress** | **Double** |  |  [optional]
**requestedHeight** | **Double** |  |  [optional]
**requestedWidth** | **Double** |  |  [optional]
**smooth** | **Boolean** |  |  [optional]
**width** | **Double** |  |  [optional]



