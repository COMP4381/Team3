
# PixelReader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pixelFormat** | [**PixelFormat**](PixelFormat.md) |  |  [optional]



